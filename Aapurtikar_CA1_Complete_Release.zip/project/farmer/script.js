const API_BASE = (() => {
  const host = window.location.hostname;
  const port = window.location.port;
  if (!host || host === "" || window.location.protocol === "file:") return "http://127.0.0.1:8000/api";
  if (port && port !== "8000") return "http://127.0.0.1:8000/api";
  return "/api";
})();
const screens = ["splash","login","otp","aadhaar","location","crops","home","requests","shipmentHistory","paymentHistory"];
let farmer = {
  mobile:"",aadhaar:"",state:"",centre:"",token:"",crops:[],requests:[],shipmentHistory:[],paymentHistory:[]
};
let editingCentre=false;
function esc(v){
  return String(v ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")
}
function clean(v){
  return String(v||"").replace(/\D/g,"")
}
function formatQ(q){
  return Number.isInteger(Number(q))?Number(q):Number(q).toFixed(2).replace(/0+$/,"").replace(/\.$/,"")
}
function mask(a){
  return a&&a.length>=4?"**** **** "+a.slice(-4):"****"
}
function saveSession(){
  localStorage.setItem("aapurtikar_farmer_mobile",farmer.mobile)
}
async function api(url, options={}){
  try {
    const r=await fetch(API_BASE+url,{
      headers:{
        "Content-Type":"application/json",...(options.headers||{})
   },...options
  });
    if(!r.ok){
      let m=`Request failed (${r.status})`;
      try{
        m=(await r.json()).detail||m
   }catch(e){} throw new Error(m)
  }    return r.json();
 } catch (e) {
    if (e instanceof TypeError) throw new Error("Cannot connect to Aapurtikar server. Start the FastAPI backend with: python run.py");
    throw e;
 }
}
function showScreen(id){
  screens.forEach(s=>{
    const e=document.getElementById(s);
    if(e)e.classList.remove("active")
 });
  const el=document.getElementById(id);
  if(el)el.classList.add("active");
  window.scrollTo(0,0)
}
function sendOTP(){
  const m=clean(document.getElementById("mobile").value),e=document.getElementById("mobileError");
  if(m.length!==10){
    e.textContent="Please enter a 10-digit mobile number.";
    return
 }e.textContent="";
  farmer.mobile=m;
  showScreen("otp")
}
function verifyOTP(){
  const v=clean(document.getElementById("otpInput").value),e=document.getElementById("otpError");
  if(v.length<4||v.length>6){
    e.textContent="Please enter a 4–6 digit OTP.";
    return
 }e.textContent="";
  showScreen("aadhaar")
}
function resendOTP(){
  alert("Demo OTP resent. Any 4–6 digit number is accepted.")
}
async function verifyAadhaar(){
  const a=clean(document.getElementById("aadhaarInput").value),e=document.getElementById("aadhaarError");
  if(a.length!==12){
    e.textContent="Please enter a 12-digit Aadhaar number.";
    return
 }e.textContent="";
  farmer.aadhaar=a;
  try{
    const p=await api("/farmers/by-mobile/"+encodeURIComponent(farmer.mobile));
    farmer={
      ...farmer,...p,token:p.farmerToken||""
  };
    document.getElementById("state").value=farmer.state||"";
    document.getElementById("centre").value=farmer.centre||"";
    if(farmer.token){
      renderHome();
      showScreen("home");
      await refreshFarmerData();
      return
  }
 }catch(err){} showScreen("location")
}
async function saveLocationAndContinue(){
  const state=document.getElementById("state").value,centre=document.getElementById("centre").value.trim(),e=document.getElementById("locationError");
  if(!state||!centre){
    e.textContent="Please select state and centre number.";
    return
 }e.textContent="";
  farmer.state=state;
  farmer.centre=centre;
  try{
    const p=await api("/farmers/profile",{
      method:"POST",body:JSON.stringify({
        mobile:farmer.mobile,aadhaar:farmer.aadhaar,state,centre,crops:farmer.crops
   })
  });
    farmer={
      ...farmer,...p,token:p.farmerToken||farmer.token
  };
    saveSession();
    if(editingCentre){
      editingCentre=false;
      document.getElementById("locationButton").textContent="Continue";
      renderHome();
      showScreen("home");
      await refreshFarmerData()
  }else{
      showScreen("crops");
      renderCrops()
  }
 }catch(err){
    e.textContent=err.message
 }
}
function goBackFromLocation(){
  if(editingCentre){
    editingCentre=false;
    document.getElementById("locationButton").textContent="Continue";
    showScreen("home")
 }else showScreen("aadhaar")
}
function toggleCustomCrop(){
  document.getElementById("customCropBox").classList.toggle("hidden",document.getElementById("cropSelect").value!=="other")
}
async function addCrop(){
  const s=document.getElementById("cropSelect"),custom=document.getElementById("customCrop"),q=Number(document.getElementById("quantity").value),unit=document.getElementById("unit").value,e=document.getElementById("cropError"),name=s.value==="other"?custom.value.trim():s.value;
  if(!name){
    e.textContent="Please select or enter a crop.";
    return
 }if(!q||q<=0){
    e.textContent="Please enter a valid quantity.";
    return
 }e.textContent="";
  farmer.crops.push({
    name,quantity:q,unit
 });
  await persistProfile();
  renderCrops();
  s.value="";
  custom.value="";
  document.getElementById("quantity").value="";
  toggleCustomCrop()
}
async function deleteCrop(i){
  farmer.crops.splice(i,1);
  await persistProfile();
  renderCrops();
  renderHome()
}
function cropHTML(c,i=null){
  return `<div class="crop-item"><div class="crop-icon">🌾</div><div class="crop-info"><div class="crop-name">${esc(c.name)}</div><div class="crop-quantity">${formatQ(c.quantity)} ${esc(c.unit)}</div></div>${i!==null?`<button class="delete" onclick="deleteCrop(${i})">🗑</button>`:""}</div>`
}
function renderCrops(){
  const list=document.getElementById("cropList");
  document.getElementById("cropCount").textContent=farmer.crops.length?`(${farmer.crops.length})`:"";
  list.innerHTML=farmer.crops.length?farmer.crops.map((c,i)=>cropHTML(c,i)).join(""):`<div class="empty">🌾<br><b>No crops added yet</b><br><small>Add the crops you have grown.</small></div>`
}
async function persistProfile(){
  try{
    const p=await api("/farmers/profile",{
      method:"POST",body:JSON.stringify({
        mobile:farmer.mobile,aadhaar:farmer.aadhaar,state:farmer.state,centre:farmer.centre,crops:farmer.crops
   })
  });
    farmer={
      ...farmer,...p,token:p.farmerToken||farmer.token
  };
    saveSession()
 }catch(err){
    console.error(err)
 }
}
async function generateToken(){
  const e=document.getElementById("cropError");
  if(!farmer.crops.length){
    e.textContent="Please add at least one crop.";
    return
 }await persistProfile();
  farmer.token=farmer.token||`FT-${Math.floor(1000+Math.random()*9000)}-${Math.floor(1000+Math.random()*9000)}`;
  try{
    await api("/shipments",{
      method:"POST",body:JSON.stringify({
        mobile:farmer.mobile,centre:farmer.centre,crops:farmer.crops
   })
  });
    await refreshFarmerData();
    renderHome();
    showScreen("home")
 }catch(err){
    e.textContent=err.message
 }
}
function renderHome(){
  document.getElementById("token").textContent=farmer.token||"FT-0000-0000";
  document.getElementById("homeMobile").textContent=farmer.mobile;
  document.getElementById("homeAadhaar").textContent=mask(farmer.aadhaar);
  document.getElementById("homeState").textContent=farmer.state;
  document.getElementById("homeCentre").textContent=farmer.centre;
  document.getElementById("homeCropList").innerHTML=farmer.crops.length?farmer.crops.map(c=>cropHTML(c)).join(""):`<div class="empty">No crops added.</div>`;
  const pending=farmer.requests.filter(r=>r.status==="Pending").length;
  document.getElementById("requestDot").classList.toggle("hidden",pending===0);
  document.getElementById("requestSummary").textContent=pending?`${pending} new procurement request${pending>1?"s":""} received`:"No new procurement requests"
}
function openAddCrop(){
  document.getElementById("addCropModal").classList.remove("hidden")
}
function closeAddCrop(){
  document.getElementById("addCropModal").classList.add("hidden");
  document.getElementById("modalError").textContent=""
}
function toggleModalCustom(){
  document.getElementById("modalCustomCrop").classList.toggle("hidden",document.getElementById("modalCropSelect").value!=="other")
}
async function addCropFromHome(){
  const s=document.getElementById("modalCropSelect"),custom=document.getElementById("modalCustomCrop"),q=Number(document.getElementById("modalQuantity").value),unit=document.getElementById("modalUnit").value,e=document.getElementById("modalError"),name=s.value==="other"?custom.value.trim():s.value;
  if(!name){
    e.textContent="Please select or enter a crop.";
    return
 }if(!q||q<=0){
    e.textContent="Please enter a valid quantity.";
    return
 }farmer.crops.push({
    name,quantity:q,unit
 });
  await persistProfile();
  renderHome();
  s.value="";
  custom.value="";
  document.getElementById("modalQuantity").value="";
  closeAddCrop()
}
function changeCentre(){
  editingCentre=true;
  document.getElementById("state").value=farmer.state;
  document.getElementById("centre").value=farmer.centre;
  document.getElementById("locationButton").textContent="Save Centre";
  showScreen("location")
}
async function openRequests(){
  await refreshRequests();
  renderRequests();
  showScreen("requests")
}
async function refreshRequests(){
  if(!farmer.mobile)return;
  try{
    const d=await api("/farmers/"+encodeURIComponent(farmer.mobile)+"/requests");
    farmer.requests=d.requests||[]
 }catch(e){
    console.error(e)
 }
}
async function recordShipment(){
  /* Shipment is persisted by /api/shipments. */
}
async function refreshFarmerData(){
  if(!farmer.token)return;
  try{
    const h=await api("/farmers/"+encodeURIComponent(farmer.token)+"/history");
    farmer.shipmentHistory=h.shipments||[];
    const g=await api("/farmers/"+encodeURIComponent(farmer.token)+"/grades");
    (g.grades||[]).forEach(x=>farmer.shipmentHistory.forEach(s=>(s.grading=s.grading||{},s.grading[x.crop]={
      grade:x.grade,remarks:x.remarks||"",date:x.date||""
  })));
    const p=await api("/farmers/"+encodeURIComponent(farmer.token)+"/payments");
    farmer.paymentHistory=p.payments||[];
    await refreshRequests();
    renderHome()
 }catch(e){
    console.error(e)
 }
}
function openShipmentHistory(){
  renderShipmentHistory();
  showScreen("shipmentHistory");
  refreshFarmerData().then(renderShipmentHistory)
}
function renderShipmentHistory(){
  const list=document.getElementById("shipmentHistoryList");
  if(!farmer.shipmentHistory.length){
    list.innerHTML='<div class="empty">🚚<br><b>No crop submissions yet</b><br><small>Your submitted crop details will appear here.</small></div>';
    return
 }list.innerHTML=farmer.shipmentHistory.map(s=>`<div class="request-card"><div class="request-top"><div class="request-title">🌾 Crop Submission</div><span class="badge accepted">Submitted</span></div><div class="request-meta"><b>Date:</b> ${esc(s.date)}<br><b>Token:</b> ${esc(s.token)}<br><b>Centre:</b> ${esc(s.centre)}</div><div class="request-note">${s.crops.map(c=>{const g=s.grading&&s.grading[c.name];return `<div><b>${
    esc(c.name)
 }</b> - ${
    formatQ(c.quantity)
 } ${
    esc(c.unit)
 }<br><b>Grade:</b> ${
    g?esc(g.grade):"Pending"
 }${
    g&&g.remarks?`<br><b>Remarks:</b> ${esc(g.remarks)}`:""
 }${
    g&&g.date?`<br><small>Graded: ${esc(g.date)}</small>`:""
 }</div>`}).join("")}</div></div>`).join("")
}
async function openPaymentHistory(){
  await refreshFarmerData();
  renderPaymentHistory();
  showScreen("paymentHistory")
}
function renderPaymentHistory(){
  const list=document.getElementById("paymentHistoryList");
  if(!farmer.paymentHistory.length){
    list.innerHTML='<div class="empty">💰<br><b>No payment history yet</b><br><small>Payment details will appear here after procurement is completed.</small></div>';
    return
 }list.innerHTML=farmer.paymentHistory.map(p=>`<div class="request-card"><div class="request-top"><div class="request-title">💰 Payment</div><span class="badge ${p.status==="Success"?"accepted":"pending"}">${esc(p.status)}</span></div><div class="request-meta"><b>Date:</b> ${esc(p.date)}<br><b>Token:</b> ${esc(p.token||farmer.token)}<br><b>Amount:</b> ₹${Number(p.amount||0).toFixed(2)}<br><b>Weight:</b> ${formatQ(p.weight||0)} quintal<br><b>Account:</b> ${esc(p.account||"-")}</div><div class="request-note">${p.status==="Success"?"Payment completed successfully.":"Payment will be updated after procurement is completed."}</div></div>`).join("")
}
function renderRequests(){
  const list=document.getElementById("requestList");
  if(!farmer.requests.length){
    list.innerHTML='<div class="empty">📭<br><b>No procurement requests</b><br><small>Government procurement requests will appear here.</small></div>';
    return
 }list.innerHTML=farmer.requests.map((r,i)=>`<div class="request-card"><div class="request-top"><div class="request-title">🌾 ${esc(r.crop)} Request</div><span class="badge ${r.status.toLowerCase()}">${esc(r.status)}</span></div><div class="request-meta"><b>Requested quantity:</b> ${formatQ(r.quantity)} ${esc(r.unit)}<br><b>Centre:</b> ${esc(r.centre)}<br><b>Reporting date:</b> ${esc(r.date)}<br><b>Time:</b> ${esc(r.time)}<br><b>From:</b> ${esc(r.worker)}</div><div class="request-note">${esc(r.note)}</div>${r.status==="Pending"?`<div class="request-actions"><button class="accept" onclick="respondRequest(${i},'Accepted')">Accept Request</button><button class="decline" onclick="respondRequest(${i},'Declined')">Decline</button></div>`:""}</div>`).join("")
}
async function respondRequest(i,status){
  try{
    await api("/requests/"+farmer.requests[i].id,{
      method:"PATCH",body:JSON.stringify({
        status
   })
  });
    farmer.requests[i].status=status;
    renderRequests();
    renderHome();
    alert(status==="Accepted"?"Request accepted. Please report at the centre on the given date and time.":"Request declined.")
 }catch(e){
    alert(e.message)
 }
}
async function logout(){
  if(!confirm("Are you sure you want to logout?"))return;
  localStorage.removeItem("aapurtikar_farmer_mobile");
  farmer={
    mobile:"",aadhaar:"",state:"",centre:"",token:"",crops:[],requests:[],shipmentHistory:[],paymentHistory:[]
 };
  document.getElementById("mobile").value="";
  showScreen("login")
}
function load(){
  const m=localStorage.getItem("aapurtikar_farmer_mobile");
  if(m)farmer.mobile=m
}
async function boot(){
  load();
  setTimeout(async()=>{
    if(farmer.mobile){
      try{
        const p=await api("/farmers/by-mobile/"+encodeURIComponent(farmer.mobile));
        farmer={
          ...farmer,...p,token:p.farmerToken||""
    };
        await refreshFarmerData();
        renderHome();
        showScreen("home");
        return
   }catch(e){}
  }showScreen("login")
 },700)
}boot();
